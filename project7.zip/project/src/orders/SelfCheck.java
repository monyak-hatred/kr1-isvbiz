package orders;

/** Самопроверка. Запуск: java -cp out orders.SelfCheck */
public class SelfCheck {
    private static int passed, failed;
    private static final Product P1 = new Product("P1", "Ноутбук", 1000);
    private static final Product P2 = new Product("P2", "Мышь", 25.5);

    public static void main(String[] args) {
        OrderService svc = new OrderService();
        Employee e = new Employee("E1", "Иванов");

        Order o = svc.createOrder(e);
        o.addProduct(P1, 2); o.addProduct(P2, 4);
        check("итог 2*1000 + 4*25.5 = 2102", o.total() == 2102.0);
        o.addProduct(P1, 3);
        check("повтор объединён в одну строку", o.getItems().size() == 2 && o.getItems().get(0).getQuantity() == 5);
        check("итог пересчитан после объединения 5*1000 + 102", o.total() == 5102.0);
        o.removeProduct("P2");
        check("удаление по id", o.getItems().size() == 1 && o.total() == 5000.0);
        bad("удаление отсутствующего", () -> o.removeProduct("XX"));

        Order b = svc.createOrder(e);
        b.addProduct(P1, 1);
        check("количество 1 допустимо (нижняя граница)", b.total() == 1000.0);
        b.addProduct(P2, 10);
        check("количество 10 допустимо (верхняя граница)", b.getItems().get(1).getQuantity() == 10);
        bad("количество 0", () -> new Order(e).addProduct(P1, 0));
        bad("количество 11", () -> new Order(e).addProduct(P1, 11));
        bad("количество -5", () -> new Order(e).addProduct(P1, -5));
        bad("объединение превышает 10 (9+2)", () -> { Order x = new Order(e); x.addProduct(P1, 9); x.addProduct(P1, 2); });
        check("объединение до ровно 10 (9+1)", okRun(() -> { Order x = new Order(e); x.addProduct(P1, 9); x.addProduct(P1, 1); }));
        bad("тот же id, другая цена", () -> { Order x = new Order(e); x.addProduct(P1, 1); x.addProduct(new Product("P1", "Ноутбук", 999), 1); });

        bad("цена 0", () -> new Product("A", "Имя", 0));
        bad("цена отрицательная", () -> new Product("A", "Имя", -1));
        bad("цена NaN", () -> new Product("A", "Имя", Double.NaN));
        bad("пустой id товара", () -> new Product("", "Имя", 1));
        bad("пустое имя товара", () -> new Product("A", "  ", 1));
        bad("null сотрудник", () -> new Order(null));
        bad("null товар", () -> new Order(e).addProduct(null, 1));

        bad("подтверждение пустого заказа", () -> svc.confirm(new Order(e)));
        svc.confirm(o);
        check("статус CONFIRMED", o.getStatus() == OrderStatus.CONFIRMED);
        badState("add после confirm", () -> o.addProduct(P2, 1));
        badState("remove после confirm", () -> o.removeProduct("P1"));
        badState("повторный confirm", () -> o.confirm());
        check("итог после confirm не изменился", o.total() == 5000.0);
        bad("getItems только для чтения", () -> o.getItems().clear());
        check("состав цел после попытки изменить", o.getItems().size() == 1);

        System.out.println("Пройдено: " + passed + ", провалено: " + failed);
        if (failed > 0) System.exit(1);
    }

    private static boolean okRun(Runnable r) {
        try { r.run(); return true; } catch (RuntimeException ex) { return false; }
    }
    private static void bad(String name, Runnable r) {
        try { r.run(); check(name + " (исключение не выброшено)", false); }
        catch (IllegalArgumentException | IllegalStateException | UnsupportedOperationException ex) {
            check(name + " -> " + ex.getClass().getSimpleName() + ": " + ex.getMessage(), true);
        }
    }
    private static void badState(String name, Runnable r) {
        try { r.run(); check(name + " (исключение не выброшено)", false); }
        catch (IllegalStateException ex) { check(name + " -> " + ex.getMessage(), true); }
    }
    private static void check(String name, boolean ok) {
        if (ok) passed++; else failed++;
        System.out.println((ok ? "OK   " : "FAIL ") + name);
    }
}
