package orders;

/** Товар: уникальный id, наименование, положительная цена. Неизменяем. */
public class Product {
    private final String id;
    private final String name;
    private final double price;

    public Product(String id, String name, double price) {
        this.id = Employee.requireText(id, "id товара");
        this.name = Employee.requireText(name, "наименование товара");
        if (Double.isNaN(price) || Double.isInfinite(price) || price <= 0) {
            throw new IllegalArgumentException("Цена должна быть положительной: " + price);
        }
        this.price = price;
    }
    public String getId() { return id; }
    public String getName() { return name; }
    public double getPrice() { return price; }

    /** Тот же id, но другие имя/цена — конфликт данных. */
    boolean sameData(Product o) {
        return name.equals(o.name) && Double.compare(price, o.price) == 0;
    }
}
