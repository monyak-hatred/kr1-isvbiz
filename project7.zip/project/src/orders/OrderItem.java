package orders;

/** Позиция заказа: товар и количество 1..MAX_QUANTITY. */
public class OrderItem {
    private final Product product;
    private int quantity;

    public OrderItem(Product product, int quantity) {
        if (product == null) {
            throw new IllegalArgumentException("Товар не задан");
        }
        checkQuantity(quantity);
        this.product = product;
        this.quantity = quantity;
    }

    private static void checkQuantity(int q) {
        if (q < OrderLimits.MIN_QUANTITY || q > OrderLimits.MAX_QUANTITY) {
            throw new IllegalArgumentException("Количество " + q + " вне диапазона "
                    + OrderLimits.MIN_QUANTITY + ".." + OrderLimits.MAX_QUANTITY);
        }
    }

    /** Объединение повторной позиции; сумма не должна превысить максимум. */
    void increase(int delta) {
        if (delta < OrderLimits.MIN_QUANTITY) {
            throw new IllegalArgumentException("Прирост количества должен быть >= " + OrderLimits.MIN_QUANTITY);
        }
        checkQuantity(quantity + delta);
        quantity += delta;
    }

    public Product getProduct() { return product; }
    public int getQuantity() { return quantity; }
    public double getLineTotal() { return product.getPrice() * quantity; }
}
