package orders;

public class Employee {
    private final String id;
    private final String fullName;

    public Employee(String id, String fullName) {
        this.id = requireText(id, "id сотрудника");
        this.fullName = requireText(fullName, "ФИО сотрудника");
    }
    public String getId() { return id; }
    public String getFullName() { return fullName; }

    static String requireText(String v, String what) {
        if (v == null || v.trim().isEmpty()) {
            throw new IllegalArgumentException(what + " не может быть пустым");
        }
        return v.trim();
    }
}
