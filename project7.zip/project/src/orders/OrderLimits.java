package orders;

/** Единственное место числовых ограничений заказа. */
public final class OrderLimits {
    private OrderLimits() { }
    public static final int MIN_QUANTITY = 1;
    /** Максимум единиц одной позиции (вариант 1: 10) (с учётом объединения повторных добавлений). */
    public static final int MAX_QUANTITY = 10;
}
