package orders;

public enum OrderStatus { DRAFT, CONFIRMED }
