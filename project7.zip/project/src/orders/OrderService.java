package orders;

/** Сценарии работы с заказом. */
public class OrderService {
    public Order createOrder(Employee employee) {
        return new Order(employee);
    }

    /** Подтверждает заказ, предварительно проверив, что он не пуст. */
    public void confirm(Order order) {
        validateForConfirm(order);
        order.confirm();
    }

    public void validateForConfirm(Order order) {
        if (order == null) {
            throw new IllegalArgumentException("Заказ не задан");
        }
        if (order.getItems().isEmpty()) {
            throw new IllegalStateException("Нельзя подтвердить пустой заказ");
        }
    }
}
