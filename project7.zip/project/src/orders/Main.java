package orders;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Читает команды из data/sample.csv:
 * ADD;id;название;цена;кол-во | REMOVE;id | CONFIRM | TOTAL
 */
public class Main {
    public static void main(String[] args) throws Exception {
        List<String> lines = Files.readAllLines(Paths.get(args.length > 0 ? args[0] : "data/sample.csv"), StandardCharsets.UTF_8);
        OrderService service = new OrderService();
        Order order = service.createOrder(new Employee("E-1", "Иванов Иван"));
        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i);
            if (line.trim().isEmpty() || line.startsWith("#")) continue;
            System.out.println("строка " + (i + 1) + ": " + execute(service, order, line));
        }
    }

    static String execute(OrderService service, Order order, String line) {
        String[] p = line.split(";", -1);
        try {
            switch (p[0].trim().toUpperCase()) {
                case "ADD":
                    if (p.length != 5) return "ОШИБКА: ADD требует 4 аргумента";
                    order.addProduct(new Product(p[1], p[2], Double.parseDouble(p[3].trim())), Integer.parseInt(p[4].trim()));
                    return "добавлено, итог " + order.total();
                case "REMOVE":
                    if (p.length != 2) return "ОШИБКА: REMOVE требует id";
                    order.removeProduct(p[1].trim());
                    return "удалено, итог " + order.total();
                case "CONFIRM":
                    service.confirm(order);
                    return "подтверждён, итог " + order.total();
                case "TOTAL":
                    return "итог " + order.total();
                default:
                    return "ОШИБКА: неизвестная команда '" + p[0] + "'";
            }
        } catch (NumberFormatException e) {
            return "ОШИБКА: неверный формат числа";
        } catch (IllegalArgumentException | IllegalStateException e) {
            return "ОШИБКА: " + e.getMessage();
        }
    }
}
