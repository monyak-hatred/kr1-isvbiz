package orders;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Заказ сотрудника. После confirm() состав не меняется. total() считается из состава. */
public class Order {
    private final Employee employee;
    private final List<OrderItem> items = new ArrayList<>();
    private OrderStatus status = OrderStatus.DRAFT;

    public Order(Employee employee) {
        if (employee == null) {
            throw new IllegalArgumentException("Сотрудник не задан");
        }
        this.employee = employee;
    }

    public void addProduct(Product product, int quantity) {
        requireDraft();
        if (product == null) {
            throw new IllegalArgumentException("Товар не задан");
        }
        OrderItem existing = find(product.getId());
        if (existing == null) {
            items.add(new OrderItem(product, quantity));
        } else {
            if (!existing.getProduct().sameData(product)) {
                throw new IllegalArgumentException("Товар с id " + product.getId()
                        + " уже есть в заказе с другими названием или ценой");
            }
            existing.increase(quantity);
        }
    }

    public void removeProduct(String productId) {
        requireDraft();
        OrderItem existing = find(productId);
        if (existing == null) {
            throw new IllegalArgumentException("Товара с id " + productId + " нет в заказе");
        }
        items.remove(existing);
    }

    public double total() {
        double sum = 0;
        for (OrderItem item : items) {
            sum += item.getLineTotal();
        }
        return sum;
    }

    public void confirm() {
        requireDraft();
        status = OrderStatus.CONFIRMED;
    }

    /** Защитная копия: внешний код не может изменить внутренний список. */
    public List<OrderItem> getItems() { return Collections.unmodifiableList(items); }
    public Employee getEmployee() { return employee; }
    public OrderStatus getStatus() { return status; }

    private OrderItem find(String productId) {
        for (OrderItem item : items) {
            if (item.getProduct().getId().equals(productId)) {
                return item;
            }
        }
        return null;
    }

    private void requireDraft() {
        if (status != OrderStatus.DRAFT) {
            throw new IllegalStateException("Заказ подтверждён и не может быть изменён");
        }
    }
}
