package trips;

/** Недопустимый переход состояния (например, approve из DRAFT). */
public class InvalidTransitionException extends IllegalStateException {
    public InvalidTransitionException(String operation, TripStatus from) {
        super("Операция " + operation + " недопустима из состояния " + from);
    }
}
