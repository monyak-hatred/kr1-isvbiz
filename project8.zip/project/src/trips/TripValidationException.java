package trips;

/** Некорректные данные операции (даты, причина и т.п.). */
public class TripValidationException extends IllegalArgumentException {
    public TripValidationException(String message) {
        super(message);
    }
}
