package trips;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;

/**
 * Команды из data/sample.csv (даты ГГГГ-ММ-ДД):
 * CREATE;id;сотрудник;начало;конец | SUBMIT;id | APPROVE;id | REJECT;id;причина | CANCEL;id | COMPLETE;id;сегодня | LIST;статус
 */
public class Main {
    public static void main(String[] args) throws Exception {
        List<String> lines = Files.readAllLines(Paths.get(args.length > 0 ? args[0] : "data/sample.csv"), StandardCharsets.UTF_8);
        BusinessTripService service = new BusinessTripService();
        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i);
            if (line.trim().isEmpty() || line.startsWith("#")) continue;
            System.out.println("строка " + (i + 1) + ": " + execute(service, line));
        }
    }

    static String execute(BusinessTripService s, String line) {
        String[] p = line.split(";", -1);
        try {
            switch (p[0].trim().toUpperCase()) {
                case "CREATE":
                    need(p, 5);
                    Employee e = new Employee("E-" + p[2].trim(), p[2]);
                    return "создана, статус " + s.create(p[1], e, LocalDate.parse(p[3].trim()), LocalDate.parse(p[4].trim())).getStatus();
                case "SUBMIT":  need(p, 2); s.find(p[1]).submit(); return "статус " + s.find(p[1]).getStatus();
                case "APPROVE": need(p, 2); s.find(p[1]).approve(); return "статус " + s.find(p[1]).getStatus();
                case "REJECT":  need(p, 3); s.find(p[1]).reject(p[2]); return "статус " + s.find(p[1]).getStatus();
                case "CANCEL":  need(p, 2); s.find(p[1]).cancel(); return "статус " + s.find(p[1]).getStatus();
                case "COMPLETE":
                    need(p, 3);
                    s.find(p[1]).complete(LocalDate.parse(p[2].trim()));
                    return "статус " + s.find(p[1]).getStatus();
                case "LIST":
                    need(p, 2);
                    return "найдено: " + s.findByStatus(TripStatus.valueOf(p[1].trim().toUpperCase())).size();
                default:
                    return "ОШИБКА: неизвестная команда '" + p[0] + "'";
            }
        } catch (DateTimeParseException ex) {
            return "ОШИБКА: неверный формат даты (нужен ГГГГ-ММ-ДД)";
        } catch (IllegalArgumentException | IllegalStateException ex) {
            return "ОШИБКА: " + ex.getMessage();
        }
    }

    private static void need(String[] p, int n) {
        if (p.length != n) throw new IllegalArgumentException("команда " + p[0] + " ожидает " + (n - 1) + " аргумент(ов)");
    }
}
