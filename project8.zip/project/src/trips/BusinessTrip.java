package trips;

import java.time.LocalDate;

/**
 * Командировка. Статус меняется только доменными методами; setStatus нет.
 * Инварианты: данные заполнены и start <= end; допустимы только переходы из таблицы;
 * rejectionReason задан только у REJECTED и содержит >= MIN_REASON_LENGTH символов.
 */
public class BusinessTrip {
    private final String id;
    private final Employee employee;
    private final LocalDate start;
    private final LocalDate end;
    private TripStatus status = TripStatus.DRAFT;
    private String rejectionReason;

    /** Создаёт черновик. Обязательные данные проверяются при submit(), даты — уже здесь допускаются null. */
    public BusinessTrip(String id, Employee employee, LocalDate start, LocalDate end) {
        this.id = id;
        this.employee = employee;
        this.start = start;
        this.end = end;
    }

    public void submit() {
        requireStatus("submit", TripStatus.DRAFT);
        validateRequiredData();          // сначала проверка данных, статус не трогаем при ошибке
        status = TripStatus.SUBMITTED;
    }

    public void approve() {
        requireStatus("approve", TripStatus.SUBMITTED);
        status = TripStatus.APPROVED;
    }

    public void reject(String reason) {
        requireStatus("reject", TripStatus.SUBMITTED);
        String r = reason == null ? "" : reason.trim();
        if (r.length() < TripRules.MIN_REASON_LENGTH) {
            throw new TripValidationException("Причина отклонения должна содержать минимум "
                    + TripRules.MIN_REASON_LENGTH + " символов");
        }
        rejectionReason = r;
        status = TripStatus.REJECTED;
    }

    public void cancel() {
        if (status != TripStatus.DRAFT && status != TripStatus.SUBMITTED && status != TripStatus.APPROVED) {
            throw new InvalidTransitionException("cancel", status);
        }
        status = TripStatus.CANCELLED;
    }

    /** Завершение возможно только из APPROVED и строго после даты окончания (today > end). */
    public void complete(LocalDate today) {
        requireStatus("complete", TripStatus.APPROVED);
        if (today == null) {
            throw new TripValidationException("Текущая дата не задана");
        }
        if (!today.isAfter(end)) {
            throw new TripValidationException("Завершить командировку можно только после даты окончания "
                    + end + " (сегодня " + today + ")");
        }
        status = TripStatus.COMPLETED;
    }

    private void requireStatus(String operation, TripStatus required) {
        if (status != required) {
            throw new InvalidTransitionException(operation, status);
        }
    }

    private void validateRequiredData() {
        if (id == null || id.trim().isEmpty()) throw new TripValidationException("Не задан id командировки");
        if (employee == null) throw new TripValidationException("Не задан сотрудник");
        if (start == null) throw new TripValidationException("Не задана дата начала");
        if (end == null) throw new TripValidationException("Не задана дата окончания");
        if (end.isBefore(start)) throw new TripValidationException("Дата окончания " + end + " раньше даты начала " + start);
    }

    public String getId() { return id; }
    public Employee getEmployee() { return employee; }
    public LocalDate getStart() { return start; }
    public LocalDate getEnd() { return end; }
    public TripStatus getStatus() { return status; }
    public String getRejectionReason() { return rejectionReason; }
}
