package trips;

import java.time.LocalDate;

/** Самопроверка. Запуск: java -cp out trips.SelfCheck */
public class SelfCheck {
    private static int passed, failed;
    private static final Employee EMP = new Employee("E1", "Иванов");
    private static final LocalDate S = LocalDate.of(2026, 11, 10), E = LocalDate.of(2026, 11, 14);

    interface Op { void run(BusinessTrip t); }

    public static void main(String[] args) {
        // Допустимые пути
        BusinessTrip t = draft();
        check("новый — DRAFT", t.getStatus() == TripStatus.DRAFT);
        t.submit(); check("DRAFT -> SUBMITTED", t.getStatus() == TripStatus.SUBMITTED);
        t.approve(); check("SUBMITTED -> APPROVED", t.getStatus() == TripStatus.APPROVED);
        t.complete(E.plusDays(1)); check("APPROVED -> COMPLETED (на следующий день после конца)", t.getStatus() == TripStatus.COMPLETED);

        t = submitted(); t.reject("Недостаточно обоснования"); // 24 символа
        check("SUBMITTED -> REJECTED с причиной", t.getStatus() == TripStatus.REJECTED && t.getRejectionReason().length() >= 10);

        for (String from : new String[]{"DRAFT", "SUBMITTED", "APPROVED"}) {
            BusinessTrip c = in(from); c.cancel();
            check("cancel из " + from + " -> CANCELLED", c.getStatus() == TripStatus.CANCELLED);
        }

        // Таблица переходов: недопустимые операции не меняют объект
        for (String from : new String[]{"DRAFT", "SUBMITTED", "APPROVED", "REJECTED", "CANCELLED", "COMPLETED"}) {
            if (!from.equals("DRAFT"))     illegal(from, "submit", x -> x.submit());
            if (!from.equals("SUBMITTED")) illegal(from, "approve", x -> x.approve());
            if (!from.equals("SUBMITTED")) illegal(from, "reject", x -> x.reject("Достаточно длинная причина"));
            if (!from.equals("APPROVED"))  illegal(from, "complete", x -> x.complete(E.plusDays(5)));
        }
        for (String from : new String[]{"REJECTED", "CANCELLED", "COMPLETED"}) {
            illegal(from, "cancel", x -> x.cancel());
        }

        // Данные: причина
        BusinessTrip r9 = submitted();
        valErr("причина 9 символов", r9, x -> x.reject("123456789"), TripStatus.SUBMITTED);
        valErr("причина null", r9, x -> x.reject(null), TripStatus.SUBMITTED);
        valErr("причина из пробелов", r9, x -> x.reject("          "), TripStatus.SUBMITTED);
        BusinessTrip r10 = submitted(); r10.reject("1234567890");
        check("причина ровно 10 символов допустима", r10.getStatus() == TripStatus.REJECTED);

        // Данные: даты и обязательные поля
        valErr("submit без даты начала", new BusinessTrip("T", EMP, null, E), x -> x.submit(), TripStatus.DRAFT);
        valErr("submit без даты окончания", new BusinessTrip("T", EMP, S, null), x -> x.submit(), TripStatus.DRAFT);
        valErr("submit без сотрудника", new BusinessTrip("T", null, S, E), x -> x.submit(), TripStatus.DRAFT);
        valErr("submit без id", new BusinessTrip(" ", EMP, S, E), x -> x.submit(), TripStatus.DRAFT);
        valErr("конец раньше начала", new BusinessTrip("T", EMP, E, S), x -> x.submit(), TripStatus.DRAFT);
        BusinessTrip oneDay = new BusinessTrip("T", EMP, S, S); oneDay.submit();
        check("однодневная командировка (start == end) допустима", oneDay.getStatus() == TripStatus.SUBMITTED);

        // Граница complete: today == end — нельзя, end+1 — можно
        valErr("complete в день окончания", approved(), x -> x.complete(E), TripStatus.APPROVED);
        valErr("complete до окончания", approved(), x -> x.complete(E.minusDays(1)), TripStatus.APPROVED);
        valErr("complete с null датой", approved(), x -> x.complete(null), TripStatus.APPROVED);

        // Сервис
        BusinessTripService svc = new BusinessTripService();
        svc.create("A", EMP, S, E); svc.create("B", EMP, S, E).submit();
        check("findByStatus(DRAFT) = 1", svc.findByStatus(TripStatus.DRAFT).size() == 1);
        check("findByStatus(SUBMITTED) = 1", svc.findByStatus(TripStatus.SUBMITTED).size() == 1);
        check("findByStatus(COMPLETED) = 0", svc.findByStatus(TripStatus.COMPLETED).isEmpty());
        try { svc.create("A", EMP, S, E); check("дубликат id (исключение не выброшено)", false); }
        catch (TripValidationException ex) { check("дубликат id -> " + ex.getMessage(), true); }
        try { svc.find("нет"); check("find отсутствующего (не выброшено)", false); }
        catch (TripValidationException ex) { check("find отсутствующего -> " + ex.getMessage(), true); }
        try { svc.findByStatus(TripStatus.DRAFT).clear(); check("список только для чтения (не выброшено)", false); }
        catch (UnsupportedOperationException ex) { check("список findByStatus только для чтения", true); }

        System.out.println("Пройдено: " + passed + ", провалено: " + failed);
        if (failed > 0) System.exit(1);
    }

    private static BusinessTrip draft() { return new BusinessTrip("T", EMP, S, E); }
    private static BusinessTrip submitted() { BusinessTrip t = draft(); t.submit(); return t; }
    private static BusinessTrip approved() { BusinessTrip t = submitted(); t.approve(); return t; }

    private static BusinessTrip in(String status) {
        BusinessTrip t = draft();
        switch (status) {
            case "DRAFT": break;
            case "SUBMITTED": t.submit(); break;
            case "APPROVED": t.submit(); t.approve(); break;
            case "REJECTED": t.submit(); t.reject("Причина отклонения"); break;
            case "CANCELLED": t.cancel(); break;
            case "COMPLETED": t.submit(); t.approve(); t.complete(E.plusDays(1)); break;
            default: throw new IllegalArgumentException(status);
        }
        return t;
    }

    private static void illegal(String from, String op, Op action) {
        BusinessTrip t = in(from);
        TripStatus before = t.getStatus();
        try {
            action.run(t);
            check(op + " из " + from + " (исключение не выброшено)", false);
        } catch (InvalidTransitionException ex) {
            check(op + " из " + from + " запрещён, статус не изменён", t.getStatus() == before);
        }
    }

    private static void valErr(String name, BusinessTrip t, Op action, TripStatus expectedStatus) {
        try {
            action.run(t);
            check(name + " (исключение не выброшено)", false);
        } catch (TripValidationException ex) {
            check(name + " -> " + ex.getMessage() + "; статус " + t.getStatus(), t.getStatus() == expectedStatus);
        }
    }

    private static void check(String name, boolean ok) {
        if (ok) passed++; else failed++;
        System.out.println((ok ? "OK   " : "FAIL ") + name);
    }
}
