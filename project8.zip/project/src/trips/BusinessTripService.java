package trips;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Хранит командировки и создаёт черновики. Правила переходов — только в BusinessTrip. */
public class BusinessTripService {
    private final Map<String, BusinessTrip> trips = new LinkedHashMap<>();

    public BusinessTrip create(String id, Employee employee, LocalDate start, LocalDate end) {
        if (id == null || id.trim().isEmpty()) {
            throw new TripValidationException("Не задан id командировки");
        }
        if (trips.containsKey(id.trim())) {
            throw new TripValidationException("Командировка с id " + id.trim() + " уже существует");
        }
        BusinessTrip t = new BusinessTrip(id.trim(), employee, start, end);
        trips.put(t.getId(), t);
        return t;
    }

    public BusinessTrip find(String id) {
        BusinessTrip t = id == null ? null : trips.get(id.trim());
        if (t == null) {
            throw new TripValidationException("Командировка с id " + id + " не найдена");
        }
        return t;
    }

    public List<BusinessTrip> findByStatus(TripStatus status) {
        List<BusinessTrip> result = new ArrayList<>();
        for (BusinessTrip t : trips.values()) {
            if (t.getStatus() == status) {
                result.add(t);
            }
        }
        return Collections.unmodifiableList(result);
    }
}
