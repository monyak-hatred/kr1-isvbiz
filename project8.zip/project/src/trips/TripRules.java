package trips;

/** Единственное место числовых правил командировки. */
public final class TripRules {
    private TripRules() { }
    /** Минимальная длина причины отклонения (после trim). Вариант 1: 10. */
    public static final int MIN_REASON_LENGTH = 10;
}
