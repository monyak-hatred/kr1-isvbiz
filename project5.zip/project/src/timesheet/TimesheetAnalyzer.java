package timesheet;

/** Разбор и расчёты по табелю одного сотрудника за неделю. Без Stream API. */
public class TimesheetAnalyzer {

    /** Строго разбирает строку «8;8;8;8;8» в массив из пяти чисел 0..MAX_HOURS. */
    public int[] parseHours(String line) throws TimesheetFormatException {
        if (line == null || line.trim().isEmpty()) {
            throw new TimesheetFormatException("Пустая строка табеля");
        }
        // limit -1: хвостовые пустые значения не отбрасываются ("8;8;8;8;8;" -> 6 элементов)
        String[] parts = line.split(";", -1);
        if (parts.length != Rules.DAYS_COUNT) {
            throw new TimesheetFormatException("Ожидалось " + Rules.DAYS_COUNT
                    + " значений, получено " + parts.length);
        }
        int[] hours = new int[Rules.DAYS_COUNT];
        for (int i = 0; i < parts.length; i++) {
            hours[i] = parseOne(parts[i], i + 1);
        }
        return hours;
    }

    /** Преобразует и проверяет одно значение; position — номер для сообщения. */
    private int parseOne(String raw, int position) throws TimesheetFormatException {
        String s = raw.trim();
        if (s.isEmpty()) {
            throw new TimesheetFormatException("Позиция " + position + ": пустое значение");
        }
        // Только цифры: отсекаем "+8", "-1", "8.5", "abc"; длина <= 9 исключает переполнение int
        if (s.length() > 9) {
            throw new TimesheetFormatException("Позиция " + position + ": слишком длинное значение '" + s + "'");
        }
        for (int i = 0; i < s.length(); i++) {
            if (!Character.isDigit(s.charAt(i)) || s.charAt(i) > '9') {
                throw new TimesheetFormatException("Позиция " + position
                        + ": не целое неотрицательное число '" + s + "'");
            }
        }
        int value = Integer.parseInt(s);
        if (value < Rules.MIN_HOURS || value > Rules.MAX_HOURS) {
            throw new TimesheetFormatException("Позиция " + position + ": значение " + value
                    + " вне диапазона " + Rules.MIN_HOURS + ".." + Rules.MAX_HOURS);
        }
        return value;
    }

    /** Сумма часов за неделю. */
    public int total(int[] hours) {
        int sum = 0;
        for (int i = 0; i < hours.length; i++) { // строго <, а не <=
            sum += hours[i];
        }
        return sum;
    }

    /** Среднее часов в день; для пустого массива 0. */
    public double average(int[] hours) {
        if (hours.length == 0) {
            return 0.0;
        }
        return (double) total(hours) / hours.length;
    }

    /** Количество дней, где часов больше дневной нормы. */
    public int overtimeDays(int[] hours) {
        int count = 0;
        for (int h : hours) {
            if (h > Rules.DAILY_NORM) {
                count++;
            }
        }
        return count;
    }

    /** Недельная переработка: max(0, сумма - недельная норма). */
    public int weeklyOvertime(int[] hours) {
        return Math.max(0, total(hours) - Rules.WEEKLY_NORM);
    }

    /** Итоговый отчёт или сообщение об ошибке — ветка «нет» и «да» диаграммы. */
    public String buildReport(String line) {
        try {
            int[] h = parseHours(line);
            return String.format("Сумма: %d; среднее: %.2f; дней переработки: %d; недельная переработка: %d",
                    total(h), average(h), overtimeDays(h), weeklyOvertime(h));
        } catch (TimesheetFormatException e) {
            return "ОШИБКА: " + e.getMessage();
        }
    }
}
