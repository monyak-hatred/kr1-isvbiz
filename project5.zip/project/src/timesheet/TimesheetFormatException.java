package timesheet;

/** Контролируемая ошибка разбора табеля. Сообщение содержит номер позиции (с 1). */
public class TimesheetFormatException extends Exception {
    public TimesheetFormatException(String message) {
        super(message);
    }
}
