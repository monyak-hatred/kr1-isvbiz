package timesheet;

/** Самопроверка без внешних библиотек. Запуск: java -cp out timesheet.SelfCheck */
public class SelfCheck {
    private static int failed = 0;
    private static int passed = 0;
    private static final TimesheetAnalyzer A = new TimesheetAnalyzer();

    public static void main(String[] args) {
        // базовые расчёты
        int[] typical = {8, 8, 8, 8, 8};
        check("сумма 8x5", A.total(typical) == 40);
        check("среднее 8x5", A.average(typical) == 8.0);
        check("дней переработки 8x5 = 0", A.overtimeDays(typical) == 0);
        check("недельная переработка 8x5 = 0", A.weeklyOvertime(typical) == 0);
        int[] over = {11, 12, 10, 8, 8};
        check("дней переработки 11,12 = 2 (ровно 10 не переработка)", A.overtimeDays(over) == 2);
        check("недельная переработка 49-40 = 9", A.weeklyOvertime(over) == 9);
        check("день ровно 10 часов — не переработка", A.overtimeDays(new int[]{10, 10, 10, 10, 10}) == 0);
        check("день 11 часов — переработка", A.overtimeDays(new int[]{11, 0, 0, 0, 0}) == 1);
        check("5x10 = 50: недельная переработка 10", A.weeklyOvertime(new int[]{10, 10, 10, 10, 10}) == 10);
        check("недельная переработка не отрицательна", A.weeklyOvertime(new int[]{1, 1, 1, 1, 1}) == 0);

        // граничные проверки разбора (>= 5 собственных)
        ok("1 типовое значение", "8;7;9;8;8", new int[]{8, 7, 9, 8, 8});
        ok("2 нижняя граница 0", "0;0;0;0;0", new int[]{0, 0, 0, 0, 0});
        ok("3 верхняя граница 16", "16;16;16;16;16", new int[]{16, 16, 16, 16, 16});
        bad("4 пустая строка", "", "Пустая строка");
        bad("5 значение 17", "8;8;17;8;8", "Позиция 3");
        bad("6 значение -1", "8;-1;8;8;8", "Позиция 2");
        bad("7 не число", "8;8;8;abc;8", "Позиция 4");
        bad("8 дробное", "8;8;8;8;7.5", "Позиция 5");
        bad("9 пустая позиция", "8;;8;8;8", "Позиция 2: пустое");
        bad("10 четыре значения", "8;8;8;8", "получено 4");
        bad("11 шесть значений", "8;8;8;8;8;8", "получено 6");
        bad("12 хвостовая ;", "8;8;8;8;8;", "получено 6");
        bad("13 null", null, "Пустая строка");
        bad("14 огромное число", "8;99999999999999999999;8;8;8", "Позиция 2");
        bad("15 знак плюс", "+8;8;8;8;8", "Позиция 1");
        ok("16 пробелы вокруг", " 8 ; 8;8 ;8;8", new int[]{8, 8, 8, 8, 8});

        System.out.println("Пройдено: " + passed + ", провалено: " + failed);
        if (failed > 0) {
            System.exit(1);
        }
    }

    private static void check(String name, boolean cond) {
        if (cond) { passed++; System.out.println("OK   " + name); }
        else { failed++; System.out.println("FAIL " + name); }
    }

    private static void ok(String name, String line, int[] expected) {
        try {
            check(name, java.util.Arrays.equals(A.parseHours(line), expected));
        } catch (TimesheetFormatException e) {
            check(name + " (неожиданная ошибка: " + e.getMessage() + ")", false);
        }
    }

    private static void bad(String name, String line, String messagePart) {
        try {
            A.parseHours(line);
            check(name + " (ошибка не выброшена)", false);
        } catch (TimesheetFormatException e) {
            check(name + " -> " + e.getMessage(), e.getMessage().contains(messagePart));
        }
    }
}
