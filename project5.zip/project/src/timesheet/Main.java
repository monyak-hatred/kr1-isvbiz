package timesheet;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

/** Читает файл (по умолчанию data/sample.csv): строка вида «метка,8;8;8;8;8» или просто «8;8;8;8;8». */
public class Main {
    public static void main(String[] args) throws IOException {
        String path = args.length > 0 ? args[0] : "data/sample.csv";
        List<String> lines = Files.readAllLines(Paths.get(path), StandardCharsets.UTF_8);
        TimesheetAnalyzer analyzer = new TimesheetAnalyzer();
        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i);
            if (line.startsWith("#")) {
                continue;
            }
            int comma = line.indexOf(',');
            String label = comma >= 0 ? line.substring(0, comma) : "строка " + (i + 1);
            String hours = comma >= 0 ? line.substring(comma + 1) : line;
            System.out.println(label + ": " + analyzer.buildReport(hours));
        }
    }
}
