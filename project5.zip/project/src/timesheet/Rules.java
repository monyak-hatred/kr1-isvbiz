package timesheet;

/**
 * Единственное место, где записаны числовые правила табеля.
 * Вариант из раздела 11 меняет ровно одну константу ниже.
 */
public final class Rules {
    private Rules() { }

    /** Сколько значений должно быть в строке (рабочих дней). */
    public static final int DAYS_COUNT = 5;
    /** Нижняя граница часов за день (включительно). */
    public static final int MIN_HOURS = 0;
    /** Верхняя граница часов за день (включительно). Варианты 2, 5, 8 меняют её. */
    public static final int MAX_HOURS = 16;
    /** День считается переработкой, если часов БОЛЬШЕ этого значения. Вариант 1: норма 10. */
    public static final int DAILY_NORM = 10;
    /** Недельная норма; переработка = max(0, сумма - WEEKLY_NORM). Варианты 3, 6. */
    public static final int WEEKLY_NORM = 40;
}
