package approval;

import static approval.ApprovalRoute.*;
import static approval.RiskLevel.*;

/** Самопроверка. Запуск: java -cp out approval.SelfCheck */
public class SelfCheck {
    private static int passed, failed;
    private static final ApprovalRouter R = new ApprovalRouter();

    public static void main(String[] args) {
        // Таблица решений: сумма, срочно, риск, перс.данные -> маршрут
        t(1, 5, false, LOW, false, STANDARD);
        t(2, 5, true, LOW, false, FAST_TRACK);
        t(3, 9, false, LOW, false, STANDARD);          // граница снизу
        t(4, 9, true, MEDIUM, false, FAST_TRACK);
        t(5, 10, false, LOW, false, FINANCE_REVIEW);    // граница включена
        t(6, 11, false, MEDIUM, false, FINANCE_REVIEW);
        t(7, 10, true, LOW, false, FINANCE_REVIEW);     // срочность не обходит финансы
        t(8, 5, false, HIGH, false, DIRECTOR_REVIEW);
        t(9, 50, true, HIGH, false, DIRECTOR_REVIEW);   // HIGH строже суммы
        t(10, 5, false, LOW, true, SECURITY_REVIEW);
        t(11, 100, true, HIGH, true, SECURITY_REVIEW);   // перс.данные строже всего
        t(12, 0, false, LOW, false, STANDARD);               // нижняя граница суммы
        // Ошибочные входные данные
        bad("отрицательная сумма", () -> R.route(-1, false, LOW, false));
        bad("риск null", () -> R.route(1, false, null, false));
        // Разбор строк
        s("Main: корректная", "5;false;low;false", "STANDARD");
        s("Main: пустая строка", "", "ОШИБКА");
        s("Main: не число", "abc;false;low;false", "ОШИБКА");
        s("Main: неизвестный риск", "100;false;critical;false", "ОШИБКА");
        s("Main: не boolean", "100;yes;low;false", "ОШИБКА");
        s("Main: три поля", "100;false;low", "ОШИБКА");
        System.out.println("Пройдено: " + passed + ", провалено: " + failed);
        if (failed > 0) System.exit(1);
    }

    private static void t(int n, long amount, boolean urgent, RiskLevel risk, boolean pd, ApprovalRoute exp) {
        ApprovalRoute got = R.route(amount, urgent, risk, pd);
        check("#" + n + " (" + amount + ", срочно=" + urgent + ", " + risk + ", пд=" + pd + ") -> " + got, got == exp);
    }
    private static void bad(String name, Runnable r) {
        try { r.run(); check(name + " (исключение не выброшено)", false); }
        catch (IllegalArgumentException e) { check(name + " -> " + e.getMessage(), true); }
    }
    private static void s(String name, String line, String contains) {
        String res = Main.process(R, line);
        check(name + " -> " + res, res.contains(contains));
    }
    private static void check(String name, boolean ok) {
        if (ok) passed++; else failed++;
        System.out.println((ok ? "OK   " : "FAIL ") + name);
    }
}
