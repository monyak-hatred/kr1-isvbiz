package approval;

/**
 * Выбор маршрута согласования. Правила проверяются от самого строгого к общему:
 * персональные данные -> риск HIGH -> сумма >= порога (вариант 1: 10) -> срочность -> STANDARD.
 * Порог лежит только здесь (константа FINANCE_LIMIT).
 */
public class ApprovalRouter {
    private static final long FINANCE_LIMIT = 10L;

    public ApprovalRoute route(long amount, boolean urgent, RiskLevel risk, boolean personalData) {
        if (amount < 0) {
            throw new IllegalArgumentException("Сумма не может быть отрицательной: " + amount);
        }
        if (risk == null) {
            throw new IllegalArgumentException("Уровень риска не задан");
        }
        if (personalData) {
            return ApprovalRoute.SECURITY_REVIEW;   // самое строгое: перекрывает всё остальное
        }
        if (risk == RiskLevel.HIGH) {
            return ApprovalRoute.DIRECTOR_REVIEW;
        }
        if (isFinanceReviewRequired(amount)) {
            return ApprovalRoute.FINANCE_REVIEW;
        }
        if (urgent) {                                // сюда попадаем только при сумме < порога
            return ApprovalRoute.FAST_TRACK;
        }
        return ApprovalRoute.STANDARD;
    }

    private boolean isFinanceReviewRequired(long amount) {
        return amount >= FINANCE_LIMIT;              // ровно 10 — уже финансовое согласование
    }
}
