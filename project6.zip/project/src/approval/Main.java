package approval;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

/** Читает data/sample.csv: «сумма;срочно(true/false);риск;персональные данные(true/false)». */
public class Main {
    public static void main(String[] args) throws Exception {
        List<String> lines = Files.readAllLines(Paths.get(args.length > 0 ? args[0] : "data/sample.csv"), StandardCharsets.UTF_8);
        ApprovalRouter router = new ApprovalRouter();
        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i);
            if (line.trim().isEmpty() || line.startsWith("#")) continue;
            System.out.println("строка " + (i + 1) + ": " + process(router, line));
        }
    }

    static String process(ApprovalRouter router, String line) {
        String[] p = line.split(";", -1);
        if (p.length != 4) return "ОШИБКА: ожидалось 4 поля, получено " + p.length;
        try {
            long amount = Long.parseLong(p[0].trim());
            boolean urgent = parseBool(p[1], "срочность");
            RiskLevel risk = parseRisk(p[2]);
            boolean pd = parseBool(p[3], "персональные данные");
            return router.route(amount, urgent, risk, pd).toString();
        } catch (NumberFormatException e) {
            return "ОШИБКА: сумма не является целым числом '" + p[0].trim() + "'";
        } catch (IllegalArgumentException e) {
            return "ОШИБКА: " + e.getMessage();
        }
    }

    private static RiskLevel parseRisk(String s) {
        try {
            return RiskLevel.valueOf(s.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("неизвестный уровень риска '" + s.trim() + "' (LOW, MEDIUM, HIGH)");
        }
    }

    private static boolean parseBool(String s, String field) {
        String v = s.trim().toLowerCase();
        if (v.equals("true")) return true;
        if (v.equals("false")) return false;
        throw new IllegalArgumentException("поле «" + field + "» должно быть true/false, получено '" + s.trim() + "'");
    }
}
