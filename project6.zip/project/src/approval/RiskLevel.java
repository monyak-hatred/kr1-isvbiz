package approval;

/** Уровень риска заявки. */
public enum RiskLevel {
    LOW, MEDIUM, HIGH
}
