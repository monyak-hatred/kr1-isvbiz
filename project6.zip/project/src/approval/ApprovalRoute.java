package approval;

/** Маршрут согласования заявки. */
public enum ApprovalRoute {
    STANDARD, FAST_TRACK, FINANCE_REVIEW, DIRECTOR_REVIEW, SECURITY_REVIEW
}
